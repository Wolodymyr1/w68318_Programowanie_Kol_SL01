var selectedElement = null;
        var intervalId;

        function changeColor(element, name) {
            if (selectedElement !== null) {
                selectedElement.classList.remove("active");
            }
            var currentElement = document.getElementById(name);
            if (name == "red"){
                currentElement.classList.add("active")
            }
            if (name == "yellow"){
                currentElement.classList.add("active")
            }
            if (name == "green"){
                currentElement.classList.add("active")
            }

            selectedElement = currentElement;
        }

        function startTrafficLights() {
            intervalId = setInterval(changeTrafficLights, 5000);
        }

        function changeTrafficLights() {
            if (selectedElement !== null) {
                var currentColor = selectedElement.style.backgroundColor;

                if (currentColor === "green") {
                    selectedElement.style.backgroundColor = "red";
                    setTimeout(function() {
                        selectedElement.style.backgroundColor = "yellow";
                    }, 5000);
                } else if (currentColor === "red") {
                    selectedElement.style.backgroundColor = "yellow";
                    setTimeout(function() {
                        selectedElement.style.backgroundColor = "green";
                    }, 5000);
                } else if (currentColor === "yellow") {
                    selectedElement.style.backgroundColor = "red";
                }
            }
        }

        startTrafficLights();