function validateForm() {

    var login = document.getElementById("login").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirmPassword").value;
    var phoneNumber = document.getElementById("phoneNumber").value;
    var birthDate = document.getElementById("birthDate").value;


    if (login.length < 3) {
      alert("Login musi zawierać co najmniej 3 znaki!");
      return false;
    }


    var emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (!emailRegex.test(email)) {
      alert("Wprowadź poprawny adres email!");
      return false;
    }


    if (password.length < 8) {
      alert("Hasło musi zawierać co najmniej 8 znaków!");
      return false;
    }

    if (password !== confirmPassword) {
      alert("Powtórzone hasło nie zgadza się!");
      return false;
    }

    var checkbox = document.getElementById("showAdditionalFields");
    if (checkbox.checked) {

      var phoneNumberRegex = /^\d+$/;
      if (!phoneNumberRegex.test(phoneNumber)) {
        alert("Numer telefonu może zawierać tylko cyfry!");
        return false;
      }


      var today = new Date();
      var birthDateInput = new Date(birthDate);
      var age = today.getFullYear() - birthDateInput.getFullYear();
      var monthDiff = today.getMonth() - birthDateInput.getMonth();
      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDateInput.getDate())) {
        age--;
      }
      if (age < 18) {
        alert("Musisz mieć co najmniej 18 lat!");
        return false;
      }
    }

    return true;
}
  

  var checkbox = document.getElementById("showAdditionalFields");
  checkbox.addEventListener("change", function() {
    var additionalFields = document.getElementById("additionalFields");
    additionalFields.style.display = checkbox.checked ? "block" : "none";
  })